package com.example.projekandroid

import android.os.Parcel
import android.os.Parcelable

data class dataKuliah(
    var matkul : String,
    var catatan : String
) : Parcelable{
    constructor(parcel: Parcel) : this(
        parcel.readString().toString(),
        parcel.readString().toString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(matkul)
        parcel.writeString(catatan)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<dataKuliah> {
        override fun createFromParcel(parcel: Parcel): dataKuliah {
            return dataKuliah(parcel)
        }

        override fun newArray(size: Int): Array<dataKuliah?> {
            return arrayOfNulls(size)
        }
    }
}
