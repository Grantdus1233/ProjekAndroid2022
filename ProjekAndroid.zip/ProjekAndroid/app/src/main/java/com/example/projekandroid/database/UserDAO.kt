package database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import java.net.PasswordAuthentication

@Dao
interface UserDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(user: User)

    @Query("UPDATE user SET email=:Email, username=:username, password=:password WHERE id=:Usid")
    fun update(Email: String, username: String, password: String, Usid: Int)

    @Query("SELECT * from user ORDER BY id ASC")
    fun selectall() : MutableList<User>

    @Query("SELECT * from user WHERE username=:username AND password=:password")
    fun login(username: String, password: String) : MutableList<User>


}