package com.example.projekandroid

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import database.User
import database.UserRoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async

class Register : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val DB = UserRoomDatabase.getDatabase(this)

        val email = findViewById<EditText>(R.id._regEmail)
        val username = findViewById<EditText>(R.id._regNRP)
        val password = findViewById<EditText>(R.id._regPassword)

        val btnRegist = findViewById<Button>(R.id.btnRegist)

        btnRegist.setOnClickListener {
            CoroutineScope(Dispatchers.IO).async {
                DB.userDao().insert(
                    User(0, email.text.toString(), username.text.toString(), password.text.toString())
                )
            }
            val intentLogin = Intent(this@Register, Login::class.java)
            startActivity(intentLogin)
        }
    }
}