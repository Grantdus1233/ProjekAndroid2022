package com.example.projekandroid

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var sp : SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtMatkul = findViewById<EditText>(R.id.editTextTextPersonName)
        val txtCatatan = findViewById<EditText>(R.id.editTextTextPersonName2)
        val btnAdd = findViewById<Button>(R.id.button)
        val btnPrint = findViewById<Button>(R.id.button2)
        val namaLogin = findViewById<TextView>(R.id.nama_login)

        sp = getSharedPreferences("dataSP", MODE_PRIVATE)

        val namaSp = sp.getString("spNama", null)
        val passSp = sp.getString("spPassword", null)

        namaLogin.text = namaSp

        var listMatkul : ArrayList<dataKuliah> = arrayListOf()
        btnAdd.setOnClickListener {
            listMatkul.add(
                dataKuliah(txtMatkul.text.toString(), txtCatatan.text.toString())
            )
            txtMatkul.setText("")
            txtCatatan.setText("")
        }

        btnPrint.setOnClickListener {
            val eIntent = Intent(this@MainActivity, MainActivity2::class.java).apply {
                putParcelableArrayListExtra(MainActivity2.dataterima, listMatkul)
            }
            startActivity(eIntent)
        }


    }
}