package com.example.projekandroid

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import database.UserRoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async

class Login : AppCompatActivity() {

    lateinit var sp : SharedPreferences
    private var _email : MutableList<String> = emptyList<String>().toMutableList()
    private var _username : MutableList<String> = emptyList<String>().toMutableList()
    private var _password : MutableList<String> = emptyList<String>().toMutableList()
    private var arUser = arrayListOf<user>()


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sp = getSharedPreferences("dataSP", MODE_PRIVATE)

        val DB = UserRoomDatabase.getDatabase(this)

        val username = findViewById<EditText>(R.id._logUsername)
        val password = findViewById<EditText>(R.id._logPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnRegister = findViewById<Button>(R.id.btnRegister)

        btnLogin.setOnClickListener {
            CoroutineScope(Dispatchers.IO).async {
                val useritem = DB.userDao().login(
                    username.text.toString(),
                    password.text.toString()
                )
                if (useritem.size.toString().toInt() > 0){
                    var editor = sp.edit()
                    editor.putString("spNama", username.text.toString())
                    editor.putString("spPassword", password.text.toString())
                    editor.apply()
                    val namaSp = sp.getString("spNama", null)
                    val passSp = sp.getString("spPassword", null)
                    Log.d("printnama", namaSp.toString())
                    Log.d("printpass", passSp.toString())
                    Log.d("hasil", "BERHASIL LOGIN")

                    val intentBerhasil = Intent(this@Login, MainActivity::class.java)
                    startActivity(intentBerhasil)
                }
                else{
                    Log.d("hasil", "GAGAL LOGIN")
                    val intentGagal = Intent(this@Login, Register::class.java)
                    startActivity(intentGagal)
                }
            }
        }

        btnRegister.setOnClickListener {
            val intent = Intent(this@Login, Register::class.java)
            startActivity(intent)
        }
    }
}