package com.example.projekandroid

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class user(
    var email: String?,
    var username: String?,
    var password: String?
) : Parcelable
