package com.example.projekandroid

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity2 : AppCompatActivity() {

    companion object{
        const val dataterima = "Data_Terima"
    }

    lateinit var sp : SharedPreferences


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        sp = getSharedPreferences("dataSP", MODE_PRIVATE)
        val namaSp = sp.getString("spNama", null)
        val nama_login = findViewById<TextView>(R.id.nama_login)
        nama_login.text = namaSp

        val _rvMatkul : RecyclerView

        _rvMatkul = findViewById(R.id.rvMatkul)
        val arMatkul : ArrayList<dataKuliah> = intent.getParcelableArrayListExtra(dataterima)!!
        fun tampilkanData(){

            _rvMatkul.layoutManager = LinearLayoutManager(this)
            val adapterM = adapterData(arMatkul)
            _rvMatkul.adapter = adapterM

            adapterM.setOnItemClickCallback(object : adapterData.OnItemClickCallback{
                override fun onItemClicked(data: dataKuliah) {
                    val intent = Intent(this@MainActivity2, detData::class.java)
                    intent.putExtra("kirimData", data)
                    startActivity(intent)
                }

                override fun delData(pos: Int) {
                    AlertDialog.Builder(this@MainActivity2)
                        .setTitle("HAPUS DATA")
                        .setMessage("APAKAH BENAR DATA "+ arMatkul[pos]+" akan dihapus ?")
                        .setPositiveButton(
                            "HAPUS",
                            DialogInterface.OnClickListener{ dialog, which ->
                                arMatkul.removeAt(pos)
                                tampilkanData()
                            }
                        )
                        .setNegativeButton(
                            "BATAL",
                            DialogInterface.OnClickListener{ dialog, which ->
                                Toast.makeText(
                                    this@MainActivity2,
                                    "DATA BATAL DIHAPUS",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        ).show()
                }
            })
        }
        tampilkanData()

    }
}