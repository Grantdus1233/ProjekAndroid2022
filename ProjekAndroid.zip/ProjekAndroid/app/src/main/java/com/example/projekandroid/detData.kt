package com.example.projekandroid

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class detData : AppCompatActivity() {
    lateinit var sp : SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_det_data)

        sp = getSharedPreferences("dataSP", MODE_PRIVATE)
        val namaSp = sp.getString("spNama", null)
        val nama_login = findViewById<TextView>(R.id.nama_login)
        nama_login.text = namaSp

        val _matakuliah = findViewById<TextView>(R.id.textView)
        val _catatan = findViewById<TextView>(R.id.textView2)
        val dataIntent = intent.getParcelableExtra<dataKuliah>("kirimData")
        if (dataIntent != null) {
            _matakuliah.text = dataIntent.matkul
            _catatan.text = dataIntent.catatan
        }
    }
}