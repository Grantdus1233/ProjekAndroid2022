package com.example.projekandroid

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class adapterData (
    private val listData: MutableList<dataKuliah>
) : RecyclerView.Adapter<adapterData.ListViewHolder>()
{
    private  lateinit var onItemClickCallback : OnItemClickCallback

    interface OnItemClickCallback {
        fun onItemClicked(data: dataKuliah)
        fun delData(pos: Int)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback){
        this.onItemClickCallback = onItemClickCallback
    }

    inner class ListViewHolder(itemView: View) :RecyclerView.ViewHolder(itemView){
        var _namaMatkul : TextView = itemView.findViewById(R.id.matkul)
        var _catatanMatkul : TextView = itemView.findViewById(R.id.catatan)
        var _btnDelete : Button = itemView.findViewById(R.id.btnDelete)
        var _layout : View = itemView.findViewById(R.id.card)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view : View = LayoutInflater.from(parent.context)
            .inflate(R.layout.itemdata, parent, false)
        return  ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        var data = listData[position]
        holder._namaMatkul.setText(data.matkul)
        holder._catatanMatkul.setText(data.catatan)
        holder._btnDelete.setOnClickListener {
            onItemClickCallback.delData(position)
        }
        holder._layout.setOnClickListener{
            onItemClickCallback.onItemClicked(listData[position])
        }
    }

    override fun getItemCount(): Int {
        return listData.size
    }
}